import React from "react";
import Home from "./components/User_CRUD/home";
import "./App.css";
function App() {
  return (
    <div>
      <Home />
    </div>
  );
}

export default App;
