import React, { Component } from "react";

class User extends Component {
  render() {
    return (
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td> </td>
        <td>
          <button className="btn btn-danger">Delete</button>
        </td>
      </tr>
    );
  }
}

export default User;
