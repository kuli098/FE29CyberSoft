import React, { Component } from "react";

class Users extends Component {
  render() {
   
    return (
      <div>
        <table className="table">
          <thead>
            <tr>
              <th />
              <th>Username</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone Number</th>
              <th>Type</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    );
  }
}

export default Users;
