import React from 'react';
import logo from './logo.svg';
import './App.css';
import Demo from './components/BaiTapComponent/Demo';
import DemoStateFull from './components/BaiTapComponent/DemoStateFull';
import BaiTapComponent from './components/BaiTapComponent/BaiTapComponent';

function App() {

  let title = 'CYBERSOFT';


  return (
    <div className="App">
      {title}
      <DemoStateFull />
      {/* <Demo />
      <DemoStateFull /> */}
      {/* <BaiTapComponent /> */}
      
    </div>
  );
}

export default App;
