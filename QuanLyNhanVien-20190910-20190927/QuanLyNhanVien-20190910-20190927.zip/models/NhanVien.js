//Lóp đối tượng nhân viên
function NhanVien(_maNV,_matKhau,_hoTen,_email,_ngaySinh,_chucVu){
    this.maNV = _maNV;
    this.matKhau =_matKhau;
    this.hoTen = _hoTen;
    this.email = _email;
    this.ngaySinh = _ngaySinh;
    this.chucVu = _chucVu;
}

// var nhanVien = new NhanVien();
// nhanVien.maNV = 1;
// nhanVien.hoTen = 'Nguyễn văn a';

// var nhanVien = new NhanVien(1,123,'Nguyễn văn a','01/01/2019','GiamDoc');
