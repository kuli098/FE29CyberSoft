

// // //GET: Phương thức GET dùng để đọc dữ liệu từ api hoặc file (.xml, .json)
// //Đọc file XML
// var getAjax = {
//   url: './CSDL/DanhSachNguoiDung.xml', // Đường dẫn đến file data, hoặc api từ backend cung cấp
//   type: 'GET' //Phương thức đọc dữ liệu từ file đó (hoặc đọc dữ liệu từ api của backend cung cấp)
// }

// $.ajax(getAjax).done(renderTableNguoiDung);
// //Callback function 
// function renderTableNguoiDung(result) {
//   var content = '';
//   var dsTagNguoiDung = result.getElementsByTagName('NguoiDung');
//   //Duyệt các thẻ người dùng
//   for (var i = 0; i < dsTagNguoiDung.length; i++) {
//     var tagNguoiDung = dsTagNguoiDung[i];
//     var taiKhoan = tagNguoiDung.getElementsByTagName('TaiKhoan')[0].innerHTML;
//     var email = tagNguoiDung.getElementsByTagName('Email')[0].innerHTML;
//     var hoTen = tagNguoiDung.getElementsByTagName('HoTen')[0].innerHTML;
//     content += `<tr><td> ${taiKhoan} </td>
//                 <td>${email}</td>
//                 <td>${hoTen}</td></tr>
//     `;
//   }
//   var table = `<table class="table">
//   <thead>
//     <tr>
//       <th>Tài khoản</th>
//       <th>Email</th>
//       <th>Họ tên</th>
//     </tr>
//   </thead>
//   <tbody>
//         ${content}
//   </tbody>
// </table>`
//   document.getElementById("content").innerHTML = table;
// }

//Xử lý click cho nút btnGETJSON => Lấy dữ liệu từ file json

document.getElementById('btnGETJSON').onclick = function () {
  var ajaxGetJson = {
    url: './CSDL/DanhSachNguoiDung.json',
    type: 'GET'
  }
  //Gọi ajax đọc file json
  $.ajax(ajaxGetJson).done(renderTableJson);
}

//Viết callbackfunction hiển thị dữ liệu đọc từ file json
function renderTableJson(result) {
  //Result trả về 1 mảng người dùng
  var content ='';
  for (var i = 0; i < result.length; i++) {
      var nguoiDung = result[i];
      //Tạo thẻ tr từ nội dung người dùng
      content += `
        <tr>
          <td>${nguoiDung.TaiKhoan}</td>
          <td>${nguoiDung.Email}</td>
          <td>${nguoiDung.HoTen}</td>
        </tr>
      `
  }
  var table = `<table class="table">
  <thead>
    <tr>
      <th>Tài khoản</th>
      <th>Email</th>
      <th>Họ tên</th>
    </tr>
  </thead>
  <tbody>
        ${content}
  </tbody>
</table>`

  document.getElementById("content").innerHTML = table;
}








