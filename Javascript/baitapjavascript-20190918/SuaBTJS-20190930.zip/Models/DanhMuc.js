function DanhMuc(){
    this.maDanhMucPhim = "";
    this.tenDanhMucPhim = "";
    this.DanhMucPhim = [];
}